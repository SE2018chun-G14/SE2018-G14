package com.lzx.lock.New;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.lzx.lock.R;

public class My extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_layout);
        TextView nickName = findViewById(R.id.nickName);
        SharedPrefUtil sharedPrefUtil = new SharedPrefUtil("user",this);
        nickName.setText(sharedPrefUtil.getString("userName",""));
        Button button1 = (Button) findViewById(R.id.button_1);
        button1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent intent = new Intent(My.this,Main2Activity.class);
                startActivity(intent);

            }
        });

        findViewById(R.id.button_2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(My.this,ResumeActivity.class);
                startActivity(intent);

            }
        });

    }
}
