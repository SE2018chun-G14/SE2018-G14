package com.lzx.lock.New;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.lzx.lock.AppUtils;
import com.lzx.lock.R;
import com.lzx.lock.base.AppConstants;
import com.lzx.lock.module.pwd.CreatePwdActivity;
import com.lzx.lock.module.splash.SplashActivity;
import com.lzx.lock.utils.LockUtil;
import com.lzx.lock.utils.SpUtil;
import com.lzx.lock.utils.ToastUtil;
import com.lzx.lock.widget.DialogPermission;

import java.util.List;

public class Main2Activity extends AppCompatActivity{
    private int RESULT_ACTION_USAGE_ACCESS_SETTINGS = 1;
    private TextView userName;
    private TextView passWord;
    private DBService dbService;
    private SharedPrefUtil appPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        appPreferences = new SharedPrefUtil("user",this);
        dbService = DBService.getDbService();
        userName = (TextView) findViewById(R.id.edit_text1);
        passWord = (TextView) findViewById(R.id.edit_text2);


        Button button1 = (Button) findViewById(R.id.button_1);
        button1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                //                new Thread(new Runnable(){
                //                    @Override
                //                    public void run(){
                ////                        dbService.getUserData()
                //                        //dbService.insertUserData(user);
                //                        //dbService.getUserData();
                //                        //dbService.updateUserData()
                ////                        User user = new User();
                ////                        user.setUsername("pack_cn.cn.cn");
                ////                        user.setPassword("123123");
                ////                        dbService.insertUserData(user);
                //
                ////                        List<User> userData = dbService.getUserData();
                ////                        User user = userData.get(0);
                ////                        dbService.updateUserData(user.getUsername(),(Integer.parseInt(user.getPassword()) + 1) + "");
                //                    }
                //                }).start();


                final String un = userName.getText().toString().trim();
                final String pw = passWord.getText().toString().trim();

                new Thread(new Runnable(){
                    @Override
                    public void run(){
                        User user = new User();
                        user.setUsername(un);
                        user.setPassword(pw);
                        List<User> list = dbService.Login(user);
                        if(list.size() > 0){
                            Message msg = Message.obtain();
                            msg.what = 3;
                            Handler.sendMessage(msg);
                            appPreferences.putString("userName", un);
                            appPreferences.putString("passWord", pw);

                        }else{
                            Message msg = Message.obtain();
                            msg.what = 4;
                            Handler.sendMessage(msg);
                        }
                    }
                }).start();
            }
        });
        boolean isFirstLock = SpUtil.getInstance().getBoolean(AppConstants.LOCK_IS_FIRST_LOCK, true);
        if(isFirstLock){ //如果第一次
            showDialog();
        }

        Button button2 = (Button) findViewById(R.id.button_2);
        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Main2Activity.this, RegisterActivity.class);
                startActivity(intent);

            }
        });
    }

    /**
     * 弹出dialog
     */
    private void showDialog(){
        //如果没有获得查看使用情况权限和手机存在查看使用情况这个界面
        if(!LockUtil.isStatAccessPermissionSet(Main2Activity.this) && LockUtil.isNoOption(Main2Activity.this)){
            DialogPermission dialog = new DialogPermission(Main2Activity.this);
            dialog.show();
            dialog.setOnClickListener(new DialogPermission.onClickListener(){
                @Override
                public void onClick(){
                    Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
                    startActivityForResult(intent, RESULT_ACTION_USAGE_ACCESS_SETTINGS);
                }
            });
        }else{
//            gotoCreatePwdActivity();
        }
    }


    private void gotoCreatePwdActivity(){
        Intent intent = new Intent(Main2Activity.this, CreatePwdActivity.class);
        startActivity(intent);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private android.os.Handler Handler = new Handler(){
        public void handleMessage(android.os.Message msg){
            if(msg.what == 3){
                Toast.makeText(Main2Activity.this, "登录成功", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Main2Activity.this, SecondActivity.class);
                startActivity(intent);
                finish();
            }
            if(msg.what == 4){
                Toast.makeText(Main2Activity.this, "该账号不存在或密码不对", Toast.LENGTH_SHORT).show();
            }
        }
    };
}
