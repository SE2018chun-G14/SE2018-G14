package com.lzx.lock.New;


import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

public class SharedPrefUtil{
    private SharedPreferences sharePref;
    private Editor editor;

    public SharedPrefUtil(String name, Context context) {
        sharePref = context.getSharedPreferences(name, Context.MODE_PRIVATE);
        editor = sharePref.edit();
    }

    public boolean putString(String key, String value) {
        editor.putString(key, value);
        return editor.commit();
    }

    public String getString(String key, String defValue) {
        return sharePref.getString(key, defValue);
    }

    public boolean remove(String key) {
        editor.remove(key);
        return editor.commit();
    }
    public void clean(){
        editor.clear();
        editor.commit();
    }
}
