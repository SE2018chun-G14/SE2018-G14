package com.lzx.lock.New;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.lzx.lock.R;
import com.lzx.lock.base.AppConstants;
import com.lzx.lock.module.main.MainActivity;
import com.lzx.lock.module.setting.LockSettingActivity;
import com.lzx.lock.service.LockService;
import com.lzx.lock.utils.SpUtil;

public class SecondActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Button button1 = (Button) findViewById(R.id.button_1);
        button1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent intent = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(intent);

            }
        });
        //        Button button2 = (Button) findViewById(R.id.button_2);
        //        button2.setOnClickListener(new View.OnClickListener(){
        //            @Override
        //            public void onClick(View v){
        //
        //                Intent intent = new Intent(SecondActivity.this,JianDu.class);
        //                startActivity(intent);
        //
        //            }
        //        });
        //
        //        Button button3 = (Button) findViewById(R.id.button_3);
        //        button3.setOnClickListener(new View.OnClickListener(){
        //            @Override
        //            public void onClick(View v){
        //
        //                Intent intent = new Intent(SecondActivity.this,TongJiActivity.class);
        //                startActivity(intent);
        //
        //            }
        //        });


        if(SpUtil.getInstance().getBoolean(AppConstants.LOCK_STATE, false)){
            Intent intent = new Intent(SecondActivity.this, LockService.class);
            startService(intent);
        }

        Button button4 = (Button) findViewById(R.id.button_4);
        button4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent intent = new Intent(SecondActivity.this, paihangbang.class);
                startActivity(intent);

            }
        });
        Button button5 = (Button) findViewById(R.id.button_5);
        button5.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent intent = new Intent(SecondActivity.this, My.class);
                startActivity(intent);

            }
        });
    }
}

