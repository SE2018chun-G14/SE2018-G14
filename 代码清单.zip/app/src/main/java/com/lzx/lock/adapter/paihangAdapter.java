package com.lzx.lock.adapter;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.lzx.lock.New.User;
import com.lzx.lock.R;
import com.lzx.lock.bean.CommLockInfo;
import com.lzx.lock.db.CommLockInfoManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by xian on 2017/3/1.
 */

public class paihangAdapter extends RecyclerView.Adapter<paihangAdapter.MainViewHolder> {

    private List<User> mLockInfos = new ArrayList<>();

    public void setLockInfos(List<User> lockInfos) {
        mLockInfos.clear();
        mLockInfos.addAll(lockInfos);
    }

    @Override
    public MainViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_paiming_list, parent, false);
        return new MainViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MainViewHolder holder, final int position) {
        final User lockInfo = mLockInfos.get(position);
        initData(holder,lockInfo);
    }

    /**
     * 初始化数据
     */
    private void initData(MainViewHolder holder,User user) {
        holder.mAppName.setText(user.getUsername().replace("__pack__",""));
        holder.mCount.setText(user.getPassword());
    }

    @Override
    public int getItemCount() {
        return mLockInfos.size();
    }

    public class MainViewHolder extends RecyclerView.ViewHolder {
        private TextView mAppName;
        private TextView mCount;

        public MainViewHolder(View itemView) {
            super(itemView);
            mAppName = (TextView) itemView.findViewById(R.id.app_name);
            mCount = (TextView) itemView.findViewById(R.id.count);
        }
    }
}
