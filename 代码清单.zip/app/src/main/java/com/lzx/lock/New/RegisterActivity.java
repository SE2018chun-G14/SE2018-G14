package com.lzx.lock.New;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.lzx.lock.R;
import com.mysql.jdbc.StringUtils;

import java.util.List;


public class RegisterActivity extends Activity{
    private Button registerbutton;
    private TextView username;
    private TextView password;
    private TextView repassword;
    private DBService dbService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
        init();
        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String usern = username.getText().toString().trim();
                final String pw = password.getText().toString().trim();
                final String repw = repassword.getText().toString().trim();
                if (StringUtils.isNullOrEmpty(usern)) {
                    Toast.makeText(RegisterActivity.this, "账号为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (StringUtils.isNullOrEmpty(pw)) {
                    Toast.makeText(RegisterActivity.this, "密码为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (StringUtils.isNullOrEmpty(repw)) {
                    Toast.makeText(RegisterActivity.this, "第二次密码为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!repw.equals(pw)) {
                    Toast.makeText(RegisterActivity.this, "两次密码不相等", Toast.LENGTH_SHORT).show();
                    return;
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        List<User> list = dbService.getUserData(usern);
                        if (list.size() > 0) {
                            Message msg = Message.obtain();
                            msg.what = 2;
                            Handler.sendMessage(msg);

                        } else {
                            User user = new User();
                            user.setUsername(usern);
                            user.setPassword(pw);
                            Log.i("注册", "-----");
                            int i = dbService.insertUserData(user);
                            Log.i("注册", "-----" + i);
                            if (i == 1) {
                                Message msg = Message.obtain();
                                msg.what = 1;
                                Handler.sendMessage(msg);
                            }
                        }
                    }
                }).start();
            }
        });
    }

    private Handler Handler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                Toast.makeText(RegisterActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegisterActivity.this,Main2Activity.class);
                startActivity(intent);
                finish();
            }else {
                Toast.makeText(RegisterActivity.this, "该账号已经存在", Toast.LENGTH_SHORT).show();
            }
        }
    };

    private void init() {
        dbService = DBService.getDbService();
        registerbutton = (Button) findViewById(R.id.registerbutton);
        username = (TextView) findViewById(R.id.textView);
        password = (TextView) findViewById(R.id.textView3);
        repassword = (TextView) findViewById(R.id.textView4);
    }


}
