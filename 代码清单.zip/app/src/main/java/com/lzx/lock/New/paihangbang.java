package com.lzx.lock.New;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.lzx.lock.R;
import com.lzx.lock.adapter.MainAdapter;
import com.lzx.lock.adapter.paihangAdapter;
import com.lzx.lock.bean.CommLockInfo;

import java.util.ArrayList;
import java.util.List;

public class paihangbang extends Activity{
    private RecyclerView mRecyclerView;
    private paihangAdapter mMainAdapter;
    private DBService dbService;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paihangbang_layout);
        dbService = DBService.getDbService();
        //        SharedPrefUtil sharedPrefUtil = new SharedPrefUtil("user",this);
        //        appName.setText(sharedPrefUtil.getString("appname1",""));
        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(paihangbang.this));
        mMainAdapter = new paihangAdapter();
        mRecyclerView.setAdapter(mMainAdapter);
        new Thread(new Runnable(){
            @Override
            public void run(){
                final List<User> userData = dbService.getUserData();
                mRecyclerView.post(new Runnable(){
                    @Override
                    public void run(){
                        mMainAdapter.setLockInfos(userData);
                        mRecyclerView.setAdapter(mMainAdapter);
                    }
                });

            }
        }).start();
    }
}
