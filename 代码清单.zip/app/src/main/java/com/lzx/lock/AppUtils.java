package com.lzx.lock;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.text.TextUtils;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by weiwei on 2018/6/25 0025.
 */

public class AppUtils{
    public static final String PACKAGE_OTA = "com.sunmi.ota";
    public static final String PACKAGE_MARKET = "woyou.market";
    public static final String PACKAGE_HARD_WARE_KEEPER = "com.woyou.hardwarekeeper";
    public static final String PACKAGE_UDH = "com.woyou.udh";
    public static final String PACKAGE_SETTING = "com.android.settings";

    public static void getAllApps(Context context){
        //        SLog.Console("获取所有非系统应用");
        String result = "";
        PackageManager pManager = context.getPackageManager();
        //获取手机内所有应用
        List<PackageInfo> paklist = pManager.getInstalledPackages(0);
        List<PackageInfo> systemPaklist = new ArrayList<>();
        List<PackageInfo> thirdPakList = new ArrayList<>();
        for(int i = 0; i < paklist.size(); i++){
            PackageInfo pak = (PackageInfo) paklist.get(i);
            //判断是否为非系统预装的应用程序
            if((pak.applicationInfo.flags & pak.applicationInfo.FLAG_SYSTEM) <= 0){
                // customs applications
                //第三方应用
                //                if (TextUtils.isEmpty(result)) {
                //                    result = pak.applicationInfo.loadLabel(pManager).toString();
                //                } else {
                //                    result = result + "," + pak.applicationInfo.loadLabel(pManager).toString();
                //                }
                thirdPakList.add(pak);
            }else{
                //系统应用
                systemPaklist.add(pak);
            }
        }
        //        SLog.Console("设备安装非系统应用信息：" + result);
        Log.d("aaa", result);

        for(PackageInfo packageInfo : systemPaklist){
            Log.d("aaa", packageInfo.packageName + packageInfo.applicationInfo.loadLabel(pManager) + packageInfo.applicationInfo.loadIcon(pManager));
        }

        Log.d("aaa", "--------------------------------------------");

        for(PackageInfo packageInfo : thirdPakList){
            Log.d("aaa", packageInfo.packageName + packageInfo.applicationInfo.loadLabel(pManager) + packageInfo.applicationInfo.loadIcon(pManager));

        }
    }
}
