package com.lzx.lock.New;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.lzx.lock.R;

public class TongJiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tongji_activity);

    }

}
