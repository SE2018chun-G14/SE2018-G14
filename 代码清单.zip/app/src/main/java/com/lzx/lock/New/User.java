package com.lzx.lock.New;

import android.support.annotation.NonNull;

/**
 */

public class User implements Comparable{
    private String username;
    private String password;
    //    modify
    private String appname1;
    private String apptime1;


    public String getUsername(){
        return username;
    }

    public void setUsername(String username){
        this.username = username;
    }

    public String getPassword(){
        return password;
    }

    public void setPassword(String password){
        this.password = password;
    }

    public String getAppname1(){ return appname1; }

    public void setAppname1(String appname1){ this.appname1 = appname1; }

    public String getApptime1(){ return apptime1; }

    public void setApptime1(String apptime1){ this.apptime1 = apptime1; }

    @Override
    public boolean equals(Object obj){
        if(obj instanceof User){
            return ((User) obj).getUsername().equals(getUsername());
        }
        return super.equals(obj);
    }


    @Override
    public int compareTo(@NonNull Object o){
        if(o instanceof User){
            try{
                User user = (User) o;
                Integer i = Integer.parseInt(user.getPassword());
                Integer i1 = Integer.parseInt(this.getPassword());
                return i.compareTo(i1);
            }catch(Throwable e){
                return 0;
            }
        }
        return 0;
    }
}
