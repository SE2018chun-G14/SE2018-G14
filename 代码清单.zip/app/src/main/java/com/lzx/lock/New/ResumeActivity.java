package com.lzx.lock.New;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.lzx.lock.R;
import com.mysql.jdbc.StringUtils;


public class ResumeActivity extends Activity{
    private Button resumebutton;
    private TextView username;
    private TextView password;
    private TextView repassword;
    private DBService dbService;
    private SharedPrefUtil appPreferences ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resume_layout);
        init();
        resumebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String usern = username.getText().toString().trim();
                final String pw = password.getText().toString().trim();
                final String repw = repassword.getText().toString().trim();
                if(!usern.equals(appPreferences.getString("passWord",""))){
                    Toast.makeText(ResumeActivity.this, "旧密码错误", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (StringUtils.isNullOrEmpty(usern)) {
                    Toast.makeText(ResumeActivity.this, "旧密码为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (StringUtils.isNullOrEmpty(pw)) {
                    Toast.makeText(ResumeActivity.this, "密码为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (StringUtils.isNullOrEmpty(repw)) {
                    Toast.makeText(ResumeActivity.this, "第二次密码为空", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!repw.equals(pw)) {
                    Toast.makeText(ResumeActivity.this, "两次密码不相等", Toast.LENGTH_SHORT).show();
                    return;
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        int i = dbService.updateUserData(appPreferences.getString("userName",""),pw);
                        Log.i("修改结果","---"+i);
                        if (i==1) {
                            Message msg = Message.obtain();
                            msg.what = 5;
                            Handler.sendMessage(msg);
                        } else {
                        }
                    }
                }).start();
            }
        });
    }

    private Handler Handler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.what == 5) {
                Toast.makeText(ResumeActivity.this, "更改成功", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ResumeActivity.this,Main2Activity.class);
                startActivity(intent);
                finish();
            }else {

            }
        }
    };

    private void init() {
        dbService = DBService.getDbService();
        appPreferences = new SharedPrefUtil("user",this);
        resumebutton = (Button) findViewById(R.id.resumebutton);
        username = (TextView) findViewById(R.id.userName);
        password = (TextView) findViewById(R.id.passWord);
        repassword = (TextView) findViewById(R.id.rePassWord);
    }


}
